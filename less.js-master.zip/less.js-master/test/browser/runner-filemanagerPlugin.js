describe('less.js filemanager Plugin', function() {
    testLessEqualsInDocument();
});
